----- CSCI-156 Project -----
----- Group 11: Thuy Tran, Harry Patel, Ananshu Bhatt, Maria Guimaraes -----

Multi-user room with sockets and threads in python

A multi-user chat room with multiple clients using sockets and threading modules in Python

If you don't have Python installed, please install it first

To run the program:

1. Run server.py in a separate terminal.
2. Run client.py in each time in new terminal to start a new client.
3. To exit (client), press CTRL+c